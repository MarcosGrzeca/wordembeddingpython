# hate2vec
A simple method to find hate speech in web comments using Word2Vec
